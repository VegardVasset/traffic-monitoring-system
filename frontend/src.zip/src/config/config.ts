export const MOBILE_MAX_WIDTH = 550;
