import { redirect } from "next/navigation";

export default function DtsIndex() {
  redirect("/dts/overview");
}
